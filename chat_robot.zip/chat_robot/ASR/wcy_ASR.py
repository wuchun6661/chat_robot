import torch
from qwen_asr import Qwen3ASRModel


class Qwen3ASR:
    def __init__(self, name_or_path="E:\LLM_models\Qwen3-ASR-0.6B"):
        self.model = Qwen3ASRModel.from_pretrained(
            name_or_path,
            dtype=torch.bfloat16,
            device_map="cuda:0",
            # attn_implementation="flash_attention_2",
            max_inference_batch_size=4,  # Batch size limit for inference. -1 means unlimited. Smaller values can help avoid OOM.
            max_new_tokens=256,  # Maximum number of tokens to generate. Set a larger value for long audio input.
            trust_remote_code=True
        )

    def generate(self, audio_file_path, language=None):
        results = self.model.transcribe(
            audio=audio_file_path,
            language=language,  # set "Chinese" to force the language
        )
        return results


qwen3_asr = Qwen3ASR("E:\LLM_models\Qwen3-ASR-0.6B")

if __name__ == "__main__":
    res = qwen3_asr.generate(audio_file_path="../temp/temp_output.wav", language="Chinese")
    print(res[0].text)
