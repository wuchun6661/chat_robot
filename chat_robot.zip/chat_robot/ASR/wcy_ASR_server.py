from fastapi import FastAPI, HTTPException
from pydantic import BaseModel
import base64
import io
import wave
import uvicorn
from wcy_ASR import qwen3_asr

# 初始化FastAPI应用
app = FastAPI(title="WAV ASR API Server", version="1.0")
TEMP_FILE_PATH = "D:/Codes/chat_robot/temp/temp_asr.wav"


# 定义ASR请求体模型（验证输入格式）
class ASRRequest(BaseModel):
    wav_base64: str


# 根接口：验证服务运行状态（GET请求）
@app.get("/", summary="服务健康检查")
async def health_check():
    return {
        "status": "running",
        "service": "ASR API Server",
        "version": "1.0"
    }


# ASR接口：接收WAV文件并返回识别文本（POST请求）
@app.post("/asr", summary="语音识别接口", response_description="识别后的文本结果")
async def asr_handler(request: ASRRequest):
    try:
        # 1. Base64解码获取WAV二进制数据
        try:
            wav_bytes = base64.b64decode(request.wav_base64)
        except base64.binascii.Error as e:
            raise HTTPException(status_code=400, detail=f"Base64解码失败：{str(e)}")

        # 2. 验证是否为合法的WAV文件
        try:
            wav_bytes = io.BytesIO(wav_bytes)
            with wave.open(wav_bytes, "rb") as wf:
                # 可选：校验WAV文件的基础参数（如采样率、声道数）
                sample_rate = wf.getframerate()
                channels = wf.getnchannels()
                print(f"接收合法WAV文件：采样率{sample_rate}Hz，声道数{channels}")

            wav_bytes.seek(0)
            with open(TEMP_FILE_PATH, "wb") as f:
                f.write(wav_bytes.read())
                print(f"成功保存WAV文件到：{TEMP_FILE_PATH}")

            asr_text = qwen3_asr.generate(audio_file_path=TEMP_FILE_PATH, language="Chinese")

        except wave.Error as e:
            raise HTTPException(status_code=400, detail=f"无效的WAV文件：{str(e)}")
        except Exception as e:
            raise HTTPException(status_code=400, detail=f"保存wav文件失败：{str(e)}")

        # 3. 语音识别核心逻辑（此处为模拟，替换为实际ASR引擎）
        # ---- 替换区：接入科大讯飞/百度语音/本地模型等 ----
        # asr_text = "模拟识别结果：你好，这是一段测试语音"  # 模拟返回
        # -------------------------------------------------

        # 4. 返回JSON格式结果
        return {
            "code": 200,
            "message": "识别成功",
            "text": asr_text
        }

    except HTTPException:
        # 抛出已定义的HTTP异常
        raise
    except Exception as e:
        # 捕获其他未知异常
        raise HTTPException(status_code=500, detail=f"服务器内部错误：{str(e)}")

# 运行服务器（直接执行该文件时生效）
if __name__ == "__main__":
    # 启动服务器，监听本地8000端口，开启自动重载（开发模式）
    uvicorn.run(app, host="0.0.0.0", port=8001, reload=False)
