from pydantic import BaseModel, Field
from typing import Optional, List


class Message(BaseModel):
    """单条消息"""
    role: str = Field(..., description="角色: user, assistant, system")
    content: str = Field(..., description="消息内容")


class ChatRequest(BaseModel):
    """聊天请求体[citation:8]"""
    messages: List[Message] = Field(..., description="对话消息列表")
    max_tokens: Optional[int] = Field(32768, ge=1, le=32768, description="最大生成长度")
    temperature: Optional[float] = Field(0.7, ge=0.1, le=2.0, description="温度参数")
    top_p: Optional[float] = Field(0.9, ge=0.1, le=1.0, description="top-p采样参数")
    stream: Optional[bool] = Field(True, description="是否流式返回")