import asyncio

from fastapi import FastAPI, HTTPException
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
import json
import time
from typing import AsyncGenerator

from wcy_LLM import qwen_model
from schemas import ChatRequest, Message
import torch
# 创建FastAPI应用[citation:5]
app = FastAPI(
    title="Qwen3 Streaming API",
    description="基于FastAPI和Transformers的Qwen3流式推理服务",
    version="1.0.0"
)

# 添加CORS中间件
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.get("/")
async def root():
    """服务健康检查"""
    return {
        "service": "Qwen2.5-7B Streaming API",
        "status": "healthy",
        "model": qwen_model.model_name,
        "device": qwen_model.device,
        "endpoints": {
            "GET /": "健康检查",
            "POST /v1/chat/completions": "聊天补全（支持流式）",
            "GET /v1/models": "查看模型信息"
        }
    }


@app.get("/v1/models")
async def list_models():
    """列出可用模型（OpenAI兼容格式）"""
    return {
        "object": "list",
        "data": [{
            "id": qwen_model.model_name,
            "object": "model",
            "created": int(time.time()),
            "owned_by": "alibaba"
        }]
    }


@app.post("/v1/chat/completions")
async def chat_completion(request: ChatRequest):
    """
    聊天补全接口，支持流式和非流式响应
    兼容OpenAI API格式
    """

    if not request.messages:
        raise HTTPException(status_code=400, detail="消息列表不能为空")

    # 格式化提示词[citation:9]
    formatted_prompt = qwen_model.format_chat_prompt(
        [msg.model_dump() for msg in request.messages]
    )

    # 流式响应[citation:1][citation:4]
    if request.stream:
        async def stream_generator() -> AsyncGenerator[str, None]:
            """流式响应生成器（SSE格式）[citation:5]"""
            try:
                print(f"用户输入：{repr(formatted_prompt)}")
                # 生成唯一的响应ID
                response_id = f"chatcmpl-{int(time.time())}"

                pre_text = ""
                start_think_text = "<think>"
                end_think_text = "</think>"

                # print(f"回答： ",end="")
                # 流式生成内容
                async for chunk in qwen_model.generate_stream_response(
                        prompt=formatted_prompt,
                        max_new_tokens=request.max_tokens,
                        temperature=request.temperature,
                        top_p=request.top_p
                ):
                    # print(f"{chunk}", end="")
                    # 跳过思考符
                    if start_think_text in chunk or end_think_text in chunk:
                        pre_text += chunk
                        continue

                    # 没有</think>
                    if end_think_text not in pre_text:
                        data = {
                            "id": response_id,
                            "object": "chat.completion.chunk",
                            "created": int(time.time()),
                            "model": qwen_model.model_name,
                            "choices": [{
                                "index": 0,
                                "delta": {"reasoning_content": chunk, "content": None},
                                "finish_reason": None
                            }]
                        }
                    else:
                        data = {
                            "id": response_id,
                            "object": "chat.completion.chunk",
                            "created": int(time.time()),
                            "model": qwen_model.model_name,
                            "choices": [{
                                "index": 0,
                                "delta": {"reasoning_content": None, "content": chunk},
                                "finish_reason": None
                            }]
                        }

                    pre_text += chunk
                    yield f"data: {json.dumps(data, ensure_ascii=False)}\n\n"
                    await asyncio.sleep(0)

                # 发送结束标记
                end_data = {
                    "id": response_id,
                    "object": "chat.completion.chunk",
                    "created": int(time.time()),
                    "model": qwen_model.model_name,
                    "choices": [{
                        "index": 0,
                        "delta": {},
                        "finish_reason": "stop"
                    }]
                }
                yield f"data: {json.dumps(end_data, ensure_ascii=False)}\n\n"
                yield "data: [DONE]\n\n"

            except Exception as e:
                error_data = {
                    "error": str(e),
                    "message": "生成过程中出现错误"
                }
                yield f"data: {json.dumps(error_data, ensure_ascii=False)}\n\n"

        return StreamingResponse(
            stream_generator(),
            media_type="text/event-stream",
            headers={
                "Cache-Control": "no-cache",
                "Connection": "keep-alive",
                "X-Accel-Buffering": "no"
            }
        )

    # 非流式响应
    else:
        try:
            # 直接生成完整响应
            inputs = qwen_model.tokenizer(formatted_prompt, return_tensors="pt").to(qwen_model.device)

            with torch.no_grad():
                outputs = qwen_model.model.generate(
                    **inputs,
                    max_new_tokens=request.max_tokens,
                    temperature=request.temperature,
                    top_p=request.top_p,
                    do_sample=True
                )

            # 解码输出
            generated_ids = outputs[0][len(inputs["input_ids"][0]):]
            response_text = qwen_model.tokenizer.decode(generated_ids, skip_special_tokens=True)

            return {
                "id": f"chatcmpl-{int(time.time())}",
                "object": "chat.completion",
                "created": int(time.time()),
                "model": qwen_model.model_name,
                "choices": [{
                    "index": 0,
                    "message": {
                        "role": "assistant",
                        "content": response_text
                    },
                    "finish_reason": "stop"
                }],
                "usage": {
                    "prompt_tokens": len(inputs["input_ids"][0]),
                    "completion_tokens": len(generated_ids),
                    "total_tokens": len(inputs["input_ids"][0]) + len(generated_ids)
                }
            }

        except Exception as e:
            raise HTTPException(status_code=500, detail=str(e))


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8002,
        reload=False,
        timeout_keep_alive=0  # 长连接保持时间[citation:8]
    )