import torch
from transformers import AutoTokenizer, AutoModelForCausalLM, TextIteratorStreamer
from threading import Thread
from typing import Generator


class QwenModel:
    """Qwen2.5-7B模型加载与流式生成管理类"""

    def __init__(self, model_name: str = "Qwen/Qwen2.5-7B-Instruct"):
        self.model_name = model_name
        self.device = "cuda" if torch.cuda.is_available() else "cpu"
        # self.device = "cpu"
        print(f"正在加载模型: {model_name} 到设备: {self.device}")

        # 加载tokenizer和模型[citation:8]
        self.tokenizer = AutoTokenizer.from_pretrained(
            model_name,
            trust_remote_code=True
        )

        # 加载模型（根据可用内存调整）
        self.model = AutoModelForCausalLM.from_pretrained(
            model_name,
            dtype=torch.bfloat16 if self.device == "cuda" else torch.bfloat16,
            device_map="auto" if self.device == "cuda" else None,
            trust_remote_code=True,

        )

        # 设置为评估模式
        self.model.eval()
        print("模型加载完成！")

    def format_chat_prompt(self, messages: list) -> str:
        """将对话消息格式化为模型输入的文本"""
        # Qwen2.5使用特殊的聊天模板
        text = self.tokenizer.apply_chat_template(
            messages,
            tokenize=False,
            add_generation_prompt=True
        )
        return text

    async def generate_stream_response(
            self,
            prompt: str,
            max_new_tokens: int = 32768,
            temperature: float = 0.7,
            top_p: float = 0.9
    ) -> Generator[str, None, None]:
        """流式生成响应[citation:9]"""

        # 准备输入
        inputs = self.tokenizer(prompt, return_tensors="pt").to(self.device)

        # 创建异步流式器（关键：使用TextIteratorStreamer）[citation:9]
        streamer = TextIteratorStreamer(
            self.tokenizer,
            timeout=60.0,
            skip_prompt=True,
            skip_special_tokens=True
        )

        # 生成参数
        generation_kwargs = {
            **inputs,
            "streamer": streamer,
            "max_new_tokens": max_new_tokens,
            "temperature": temperature,
            "top_p": top_p,
            "do_sample": True,
            "repetition_penalty": 1.1,
            "use_cache": True,  # 启用KV缓存
        }

        with torch.inference_mode():
            # 在独立线程中运行生成过程
            thread = Thread(target=self.model.generate, kwargs=generation_kwargs)
            thread.start()

            # 流式返回生成的内容
            answer = ""
            for new_text in streamer:
                answer += new_text
                yield new_text


# 全局模型实例
# qwen_model = QwenModel("E:\LLM_models\Qwen3-8B")
qwen_model = QwenModel("E:\LLM_models\Qwen3-0.6B")


