import base64
import io
import os
import wave

import pyaudio
import speech_recognition as sr

TEMP_FILE_PATH = "D:/Codes/chat_robot/temp/temp_audio_input.wav"


class AudioRecorder:
    def __init__(self, rate=16000):
        """初始化录音器，设置采样率"""
        self.rate = rate
        self.recognizer = sr.Recognizer()

    def record(self):
        """录制音频并返回音频数据"""
        with sr.Microphone(sample_rate=self.rate) as source:
            print(f"正在监听说话...")
            audio = None
            while True:
                try:
                    # 录音，设置超时1秒以便更新进度条
                    audio = self.recognizer.listen(source, timeout=1, phrase_time_limit=15)
                    break  # 录音成功，跳出循环
                except sr.WaitTimeoutError:
                    continue
        # 返回音频数据
        audio_data = audio.get_wav_data()
        return io.BytesIO(audio_data)

    @staticmethod
    def save_wav(audio_data, filename=TEMP_FILE_PATH):
        """
        将io.BytesIO对象中的WAV数据保存为本地WAV文件
        :param audio_data: 存储了WAV二进制数据的io.BytesIO对象
        :param filename: 输出本地WAV文件的路径（如"output.wav"）
        """
        try:
            # 关键步骤1：将BytesIO的文件指针移到流的起始位置（必做！）
            # 因为BytesIO对象在写入/读取后，指针会停在末尾，直接读取会得到空数据
            audio_data.seek(0)

            # 关键步骤2：以二进制写入模式（wb）打开本地文件，写入数据
            with open(filename, 'wb') as f:
                # 读取BytesIO中的所有二进制数据，写入本地文件
                f.write(audio_data.read())

            print(f"成功保存WAV文件到：{filename}")
        except Exception as e:
            print(f"保存失败，原因：{e}")

    def run(self):
        """运行录音功能并保存音频文件"""
        audio_data = self.record()
        return audio_data


def wav_to_base64(wav_file_path):
    """
    将本地WAV文件转换为Base64编码字符串
    :param wav_file_path: WAV文件的本地路径
    :return: Base64编码后的字符串
    """
    # 以二进制模式读取文件，with语句自动关闭文件句柄（简洁且安全）
    with open(wav_file_path, 'rb') as f:
        wav_bytes = f.read()
    # 编码为Base64并转为字符串（适配JSON传输）
    base64_str = base64.b64encode(wav_bytes).decode('utf-8')
    return base64_str


def base64_to_wav_file(base64_str: str, save_path: str) -> bool:
    """
    将Base64编码字符串转换为WAV文件并保存到指定路径

    Args:
        base64_str: 原始的WAV文件Base64编码字符串（UTF-8格式）
        save_path: WAV文件的保存路径（绝对/相对路径，需包含.wav后缀）

    Returns:
        转换成功返回True，失败返回False

    Raises:
        base64.binascii.Error: Base64编码无效
        IOError: 文件写入失败（权限不足/路径不存在等）
    """
    try:
        # 1. 解码Base64字符串为二进制数据
        # 注意：如果Base64字符串包含前缀（如"data:audio/wav;base64,"），需要先去除
        if "base64," in base64_str:
            base64_str = base64_str.split("base64,")[-1]

        wav_binary = base64.b64decode(base64_str)

        # 2. 确保保存目录存在（如果目录不存在则创建）
        save_dir = os.path.dirname(save_path)
        if save_dir and not os.path.exists(save_dir):
            os.makedirs(save_dir, exist_ok=True)

        # 3. 写入二进制数据到WAV文件
        with open(save_path, "wb") as wav_file:
            wav_file.write(wav_binary)

        print(f"WAV文件已成功保存到：{save_path}")
        return True

    except base64.binascii.Error as e:
        print(f"转换失败：无效的Base64编码 - {str(e)}")
        return False
    except IOError as e:
        print(f"文件写入失败：{str(e)}（检查路径权限/目录是否存在）")
        return False
    except Exception as e:
        print(f"未知错误：{str(e)}")
        return False

def play_wav_file(wav_file_path):
    """
    播放WAV格式的语音文件
    :param wav_file_path: WAV文件的路径（相对路径或绝对路径）
    """
    # 1. 打开WAV文件，读取文件信息
    try:
        wf = wave.open(wav_file_path, 'rb')
    except FileNotFoundError:
        print(f"错误：未找到文件 {wav_file_path}")
        return
    except Exception as e:
        print(f"错误：打开WAV文件失败，原因：{e}")
        return

    # 2. 初始化PyAudio对象
    p = pyaudio.PyAudio()

    # 3. 配置音频流参数（必须与WAV文件参数匹配，否则播放异常）
    stream = p.open(
        format=p.get_format_from_width(wf.getsampwidth()),  # 音频格式（从WAV文件获取）
        channels=wf.getnchannels(),  # 声道数（单声道/立体声，从WAV文件获取）
        rate=wf.getframerate(),  # 采样率（从WAV文件获取）
        output=True  # 标记为输出流（用于播放音频）
    )

    # 4. 读取音频数据并分块播放
    print(f"开始播放：{wav_file_path}")
    chunk = 1024  # 每次读取的音频数据块大小（可调整，不影响播放效果，仅影响内存占用）
    data = wf.readframes(chunk)  # 读取第一块数据

    while data:
        stream.write(data)  # 写入音频流进行播放
        data = wf.readframes(chunk)  # 读取下一块数据

    # 5. 播放完成后，释放所有资源（必须执行，避免资源泄露）
    print("播放结束")
    stream.stop_stream()  # 停止音频流
    stream.close()  # 关闭音频流
    p.terminate()  # 终止PyAudio对象
    wf.close()  # 关闭WAV文件


if __name__ == '__main__':
    # a = "base64"
    # base64_to_wav_file(a, "test.wav")

    rec = AudioRecorder(rate=48000)
    while True:
        audio_data = rec.run()  # 监听麦克风
        rec.save_wav(audio_data,filename=TEMP_FILE_PATH)  # 保存为wav文件

        # wav文件转base64码
        wav_base64 = wav_to_base64(TEMP_FILE_PATH)
        print(wav_base64[:200])
