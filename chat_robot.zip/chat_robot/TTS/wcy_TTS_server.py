from fastapi import FastAPI
from pydantic import BaseModel
import base64
import io
import wave
import uvicorn
from wcy_TTS import qwen3_tts, TEMP_TTS_PATH
from utils.audio_recorder import wav_to_base64


# 创建FastAPI应用实例
app = FastAPI(title="Voice Synthesis API", version="1.0")


# 定义请求体模型：接收用户输入的文本
class CloneRequest(BaseModel):
    role: str  # 用户输入的角色
    content: str


class CustomRequest(BaseModel):
    role: str  # 用户输入的角色
    content: str
    instruct: str


# 接口1：根路径，返回运行状态
@app.get("/", summary="服务器状态检查")
async def root():
    return {"status": "正在运行中", "message": "API服务器已启动，可调用/clone_voice和/custom_device接口"}


# 接口2：克隆语音接口
@app.post("/clone_voice", summary="克隆语音合成（返回WAV的Base64编码）")
async def clone_voice(request: CloneRequest):
    try:
        # 生成WAV的Base64编码
        qwen3_tts.generate_clone_voice(request.content)
        wav_base64 = wav_to_base64(TEMP_TTS_PATH)
        return {
            "code": 200,
            "message": "克隆语音生成成功",
            "data": {
                "text": request.content,
                "wav_base64": wav_base64
            }
        }
    except Exception as e:
        return {"code": 500, "message": f"生成失败：{str(e)}", "data": None}


# 接口3：自定义设备语音接口
@app.post("/custom_voice", summary="自定义设备语音合成（返回WAV的Base64编码）")
async def custom_device(request: CustomRequest):
    try:
        # 复用生成逻辑，你可根据需求为该接口定制不同的语音合成规则
        qwen3_tts.generate_custom_voice(request.content)
        wav_base64 = wav_to_base64(TEMP_TTS_PATH)

        return {
            "code": 200,
            "message": "自定义设备语音生成成功",
            "data": {
                "text": request.content,
                "wav_base64": wav_base64
            }
        }
    except Exception as e:
        return {"code": 500, "message": f"生成失败：{str(e)}", "data": None}


# 运行服务器
if __name__ == "__main__":
    # 启动uvicorn服务器，监听本地0.0.0.0:8000
    uvicorn.run(app, host="0.0.0.0", port=8003)
