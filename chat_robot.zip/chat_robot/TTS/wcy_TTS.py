import os

import torch
import soundfile as sf
from qwen_tts import Qwen3TTSModel
import wave
import pyaudio

VOICE_ORIGIN_DIR = "D:/Codes/chat_robot/resources/voice_origin"
TEMP_TTS_PATH = "D:/Codes/chat_robot/temp/temp_tts.wav"
ref_dict = {
    "zoo": (f"{VOICE_ORIGIN_DIR}/zoo.wav", "这有二倍有八倍，拿个98K了吧，狙他一枪，二标里面吗？"),
    "xiaoji": (f"{VOICE_ORIGIN_DIR}/xiaoji.wav", "有病吧没一个背包是什么鬼啊"),
    "cc": (f"{VOICE_ORIGIN_DIR}/cc.wav", "杀一晚上没杀够"),
    "chaoge": (f"{VOICE_ORIGIN_DIR}/chaoge.wav", "唉我们脸上到了这里看下看下我们来的地方。"),
    "choudayang": (f"{VOICE_ORIGIN_DIR}/choudayang.wav", "肉肉的猫粮真好吃，明天还给它吃这款猫粮。"),
    "jizhang": (f"{VOICE_ORIGIN_DIR}/jizhang.wav", "诶等一下，怎么声音这么小听不见说话呀。"),
    "zyf": (f"{VOICE_ORIGIN_DIR}/zyf.wav", "啊我说明天六点的地铁九点的飞机"),
}


class Qwen3TTS:
    def __init__(self, name_or_path="E:\LLM_models\Qwen3-TTS-12Hz-0.6B-Base"):
        self.model_name = name_or_path
        self.model = Qwen3TTSModel.from_pretrained(
            name_or_path,
            device_map="cuda:0",
            dtype=torch.bfloat16,
            # attn_implementation="flash_attention_2",
            trust_remote_code=True
        )

    def generate_clone_voice(self,
                 text,
                 ref_audio=ref_dict["zoo"][0],
                 ref_text=ref_dict["zoo"][1],
                 instruct="用非常着急的语气说",
                 output_voice_path=TEMP_TTS_PATH
                 ):
        if "base" not in self.model_name.lower():
            raise ValueError(f"{self.model_name} 模型不支持clone_voice方法")
        # generate_clone_voice speech with specific instructions
        wavs, sr = self.model.generate_voice_clone(
            text=text,
            language="Chinese",
            ref_audio=ref_audio,
            ref_text=ref_text,
            instruct=instruct
        )
        sf.write(output_voice_path, wavs[0], sr)
        return (wavs, sr)  # 一维的音频张量、采样频率(24k)

    def generate_custom_voice(self,
                              text,
                              speaker="Serena",
                              instruct="用撒娇可爱的语气说",
                              output_voice_path=TEMP_TTS_PATH
                              ):
        """
            # Speaker	语音描述	母语
            # Vivian	清澈明亮的年轻女声。    	中国人
            # Serena	温暖、柔和的年轻女性声音。	中国人
            # Uncle_Fu	成熟男声，音色醇厚。    	中国人
            # Dylan  	年轻的北京男声。       	中文（北京）
            # Eric      活泼的成都男声。       	中文（四川）
            # Ryan  	富有节奏感的男声。     	英语
            # Aiden 	阳光明媚的美国男声。    	英语
            # Ono_Anna	活泼的日本女声。       	日本人
            # Sohee 	温暖的韩国女声。       	韩国人
        """

        if "custom" not in self.model_name.lower():
            raise ValueError(f"{self.model_name} 模型不支持custom_voice方法")
        # Generate speech with specific instructions
        wavs, sr = self.model.generate_custom_voice(
            text=text,
            language="Chinese",
            speaker=speaker,
            instruct=instruct,
        )
        sf.write(output_voice_path, wavs[0], sr)
        return (wavs, sr)  # 一维的音频张量、采样频率(24k)

    @staticmethod
    def play_wav_file(wav_file_path):
        """
        播放WAV格式的语音文件
        :param wav_file_path: WAV文件的路径（相对路径或绝对路径）
        """
        # 1. 打开WAV文件，读取文件信息
        try:
            wf = wave.open(wav_file_path, 'rb')
        except FileNotFoundError:
            print(f"错误：未找到文件 {wav_file_path}")
            return
        except Exception as e:
            print(f"错误：打开WAV文件失败，原因：{e}")
            return

        # 2. 初始化PyAudio对象
        p = pyaudio.PyAudio()

        # 3. 配置音频流参数（必须与WAV文件参数匹配，否则播放异常）
        stream = p.open(
            format=p.get_format_from_width(wf.getsampwidth()),  # 音频格式（从WAV文件获取）
            channels=wf.getnchannels(),  # 声道数（单声道/立体声，从WAV文件获取）
            rate=wf.getframerate(),  # 采样率（从WAV文件获取）
            output=True  # 标记为输出流（用于播放音频）
        )

        # 4. 读取音频数据并分块播放
        print(f"开始播放：{wav_file_path}")
        chunk = 1024  # 每次读取的音频数据块大小（可调整，不影响播放效果，仅影响内存占用）
        data = wf.readframes(chunk)  # 读取第一块数据

        while data:
            stream.write(data)  # 写入音频流进行播放
            data = wf.readframes(chunk)  # 读取下一块数据

        # 5. 播放完成后，释放所有资源（必须执行，避免资源泄露）
        print("播放结束")
        stream.stop_stream()  # 停止音频流
        stream.close()  # 关闭音频流
        p.terminate()  # 终止PyAudio对象
        wf.close()  # 关闭WAV文件


# qwen3_tts = Qwen3TTS("E:\LLM_models\Qwen3-TTS-12Hz-0.6B-Base")
qwen3_tts = Qwen3TTS("E:\LLM_models\Qwen3-TTS-12Hz-0.6B-CustomVoice")

if __name__ == "__main__":
    while True:
        role = input("输入role：").strip()
        os.makedirs(role, exist_ok=True)
        text = input("请输入：").strip()
        ref_audio = ref_dict[role][0]
        ref_text = ref_dict[role][1]
        output_voice_path = f"./{role}/{text}.wav"

        qwen3_tts.generate_custom_voice(
            text,
            speaker="Serena",
            instruct="用撒娇可爱的语气说",
            output_voice_path=output_voice_path
        )

        qwen3_tts.play_wav_file(output_voice_path)

        # qwen3_tts.generate_clone_voice(
        #     text=text,
        #     ref_audio=ref_audio,
        #     ref_text=ref_text,
        #     output_voice_path=output_voice_path
        # )
