import requests
import json
from utils.audio_recorder import *
from TTS.wcy_TTS import TEMP_TTS_PATH


ASR_API = 'http://127.0.0.1:8001/asr'
LLM_API = 'http://127.0.0.1:8002/v1/chat/completions'
TTS_CLONE_API = 'http://127.0.0.1:8003/clone_voice'
TTS_CUSTOM_API = 'http://127.0.0.1:8003/custom_voice'

WARM_WORD = "小杨同学"
WARM_AUDIO_FILE = "D:/Codes/chat_robot/temp/我在.wav"


def wcy_post(url, body: dict):
    headers = {
      'Content-Type': 'application/json'
    }
    payload = json.dumps(body)
    response = requests.request("POST", url, headers=headers, data=payload)

    return response.json()


def main():
    rec = AudioRecorder(rate=48000)

    while True:
        audio_data = rec.run()  # 监听麦克风
        rec.save_wav(audio_data, filename=TEMP_FILE_PATH)  # 保存为wav文件
        wav_base64 = wav_to_base64(TEMP_FILE_PATH)  # wav文件转base64码

        # ===== ASR ====
        res = wcy_post(ASR_API, {"wav_base64": wav_base64})

        if WARM_WORD not in res["text"][0]["text"]:
            continue

        print(f"唤醒成功")
        # # TTS生成自动回应
        # res = wcy_post(TTS_CUSTOM_API, {
        #     "role": "1",
        #     "content": "我在~",
        #     "instruct": "1"
        # })
        # base64_to_wav_file(res["data"]["wav_base64"], TEMP_TTS_PATH)
        play_wav_file(WARM_AUDIO_FILE)

        # LLM对话
        audio_data = rec.run()  # 监听麦克风
        rec.save_wav(audio_data, filename=TEMP_FILE_PATH)  # 保存为wav文件
        wav_base64 = wav_to_base64(TEMP_FILE_PATH)  # wav文件转base64码

        # ASR识别语音成文字
        res = wcy_post(ASR_API, {"wav_base64": wav_base64})

        # LLM对话
        chat_body = {
            "model": "qwen",
            "messages": [
                {
                    "role": "system",
                    "content": "你是一个臭大杨的专属智能语音助手，你能正确理解用户的问题，并给出正确的回复，且回复不要超过20个字。"
                },
                {
                    "role": "user",
                    "content": f'{res["text"][0]["text"]} /no_think'
                }
            ],
            "stream": False
        }
        res = wcy_post(LLM_API, chat_body)
        text = res["choices"][0]["message"]["content"].replace("<think>","").replace("</think>","")

        # TTS
        res = wcy_post(TTS_CUSTOM_API, {
            "role": "1",
            "content": text,
            "instruct": "1"
        })
        base64_to_wav_file(res["data"]["wav_base64"], TEMP_TTS_PATH)
        play_wav_file(TEMP_TTS_PATH)

if __name__ == '__main__':
    main()


